from django.contrib import admin
from .models import Task


# Register your models here.
class TaskAdmin (admin.ModelAdmin):
    list_display=('titre','categorie_generale','importance','completed','date_creation','date_fin','date_limite')
    list_filter=('completed','importance')
    search_fields=['titre']
admin.site.register(Task,TaskAdmin)


















