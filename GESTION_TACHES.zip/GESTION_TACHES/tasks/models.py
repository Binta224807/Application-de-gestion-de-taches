from django.db import models 
from django.contrib.auth.models import User
from django.utils import timezone
from django.conf import settings
class Task(models.Model):
    # Catégories générales
    GENERAL_CATEGORIES = [
        ('personnel', 'Personnel'),
        ('famille', 'Famille'),
        ('etudes', 'Etudes'),
        ('professionnels', 'Professionnels'),
        ('divertissements', 'Divertissements'),
    ]

    # Importance
    IMPORTANCE = [
        ('faible', 'Moins important'),
        ('moyen', 'Important'),
        ('urgent', 'Très important'),
    ]

    titre = models.CharField(max_length=255)
    categorie_generale = models.CharField(max_length=50, choices=GENERAL_CATEGORIES)
    importance = models.CharField(max_length=20, choices=IMPORTANCE, default='moyen')
    completed = models.BooleanField(default=False)
    date_creation = models.DateTimeField(auto_now_add=True)
    date_fin = models.DateTimeField(null=True, blank=True)
    date_limite = models.DateField(null=True, blank=True)
    description= models.TextField(null=True ,blank=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE
    )

    def _str_(self):
        return self.titre

    def terminer(self):
        self.completed = True
        self.date_fin = timezone.now()
        self.save()
        