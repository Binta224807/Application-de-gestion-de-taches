
from django.urls import path
from django.contrib import admin
from . import views
from .views import (
    CustomLoginView,
    register_view,
    logout_view
)
urlpatterns =[
    path('admin/',admin.site.urls),
    path('', views.home, name='home'),
     path('add/<str:categorie_generale>/', views.add_task, name='add_task'),
    path('completed/<int:task_id>/', views.completed_task, name='completed_task'),
    path('delete/<int:task_id>/', views.delete_task, name='delete_task'),
    path('history/', views.history, name='history'),
    path('graphique/', views.graphique, name='graphique'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('register/', register_view, name='register'),
    path('logout/', logout_view, name='logout'),

]
