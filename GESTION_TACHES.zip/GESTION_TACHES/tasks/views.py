from django.shortcuts import render, redirect, get_object_or_404
from .models import Task
from django.views.decorators.http import require_POST
from django.contrib.auth import login ,logout
from django.contrib.auth.views import LoginView
from .forms import RegisterForm,LoginForm
from django.contrib.auth.decorators import login_required


@login_required
def home(request):

    # 📌 catégories simples (TES mots)
    categories = [
        'personnel',
        'famille',
        'etudes',
        'professionnels',
        'divertissements',
    ]

    # 📌 toutes les tâches
    tasks = Task.objects.filter(user=request.user)

    return render(request, 'tasks/home.html', {
        'categories': categories
     })
@login_required
def graphique (request):
    # 📊 comptage pour graphique
    personnel_count = Task.objects.filter( user=request.user,categorie_generale='personnel',completed = False).count()
    famille_count = Task.objects.filter( user=request.user,categorie_generale='famille', completed = False).count()
    etudes_count = Task.objects.filter( user=request.user,categorie_generale='etudes',completed = False).count()
    professionnels_count = Task.objects.filter( user=request.user,categorie_generale='professionnels',completed = False).count()
    divertissements_count = Task.objects.filter( user=request.user,categorie_generale='divertissements',completed = False).count()
    notifications = []
    

        # 📊 données graphique
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'tasks/graphique.html',{
        'personnelCount': personnel_count,
        'familleCount': famille_count,
        'etudesCount': etudes_count,
        'professionnelsCount': professionnels_count,
        'divertissementsCount': divertissements_count,
       
        
    })

def add_task(request, categorie_generale):

    error = None

    if request.method == "POST":
        titre = request.POST.get('titre')
        importance = request.POST.get('importance')
        date_limite = request.POST.get('date_limite')
        description = request.POST.get('description')

        if not titre or not importance:
            error = "Remplis tous les champs"
        else:
            task = Task(
                titre=titre,
                categorie_generale=categorie_generale,
                importance=importance,
                description=description,
                user =request.user
            )

            if date_limite:
                task.date_limite = date_limite

            task.save()
            tasks = Task.objects.filter(user=request.user)
            return redirect('home')

    return render(request, 'tasks/add.html', {
        'categorie_generale': categorie_generale,
        'error': error
    })


@require_POST
def completed_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.completed = True
    task.save()
    return redirect('home')


@require_POST
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    task.delete()
    return redirect('home')

@login_required
def history(request):

    categories = [
        'personnel',
        'famille',
        'etudes',
        'professionnels',
        'divertissements',
    ]

    tasks = Task.objects.filter(
        user=request.user,
        completed=True
    )

    return render(request, 'tasks/history.html', {
        'categories': categories,
        'tasks': tasks,
    })

def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'tasks/register.html', {'form': form})


# LOGIN
class CustomLoginView(LoginView):

    template_name = 'tasks/login.html'

    authentication_form = LoginForm

# REGISTER
def register_view(request):

    if request.method == 'POST':

        form = RegisterForm(request.POST)

        if form.is_valid():

            user = form.save()

            login(request, user)

            return redirect('home')

    else:

        form = RegisterForm()

    return render(request, 'tasks/register.html', {
        'form': form
    })

def logout_view(request):

    logout(request)

    return redirect('login')



